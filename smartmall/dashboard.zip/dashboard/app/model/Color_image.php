<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Color_image extends Model
{
    //
}
