<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class orders_product extends Model
{
    //
}
