<title><?php echo $__env->yieldContent('title', 'Home'); ?></title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php

use App\model\Offer;

$offers = Offer::all();
$offers = Offer::all();

 ?>


 <div class="outer">
        <div class="gallery">

            <div class="master-img">

                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <i class="fa fa-angle-left" aria-hidden="true"></i>


                <img src="../storage/app/avatar/m.jpg">

            </div>

            <!--************-->

            <div class="thumbnails">


       <img class="selected" src="../storage/app/avatar/s1.jpg">
       <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <img src="../storage/app/avatar/s2.jpg">

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>


         </div>
 </div>





    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/perfect-scrollbar.min.js"></script>
    <script src="js/panelmenu.js"></script>
    <script src="js/instafeed.min.js"></script>
    <script src="js/jquery.themepunch.tools.min.js"></script>
    <script src="js/jquery.themepunch.revolution.min.js"></script>
    <script src="js/jquery.plugin.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/lazyload.min.js"></script>
    <script src="js/main.js"></script>
    <!-- form validation and sending to mail -->
    <script src="js/jquery.form.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/jquery.form-init.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){



//    Go To img-src ******************* >>>>>>>>>>>>>>>>>

$('.thumbnails img').on('click',function(){

  $(this).addClass('selected').siblings().removeClass('selected');

  $('.master-img img').hide().attr('src',$(this).attr('src')).fadeIn();


});



//    next slider ******************* >>>>>>>>>>>>>>>>>





var x = $('.master-img .fa-angle-right').on('click',function(){

        if($('.thumbnails .selected').is(':last-child'))
     {

         $('.thumbnails img').eq(0).click();

     }
  else
      {
          $('.thumbnails .selected').next().click();
      }


          });





//    prev slider *******************   >>>>>>>>>>>>>>>>>

      $('.master-img .fa-angle-left').on('click',function(){



                 if($('.thumbnails .selected').is(':first-child'))
     {

         $('.thumbnails img').eq(-1).click();

     }
  else
      {
  $('.thumbnails .selected').prev().click();
      }


           });


});








setInterval(function(){

        if($('.thumbnails .selected').is(':last-child'))
     {

         $('.thumbnails img').eq(0).click();

     }
  else
      {
          $('.thumbnails .selected').next().click();
      }

},5000);



    </script>
</body>

</html>
