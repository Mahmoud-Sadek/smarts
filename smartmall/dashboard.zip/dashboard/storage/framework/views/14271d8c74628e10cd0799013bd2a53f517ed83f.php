<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>MATJARI</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="favicon.jpg">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/slick.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/theme.css">
</head>

<body style="height:2000px">




    <header>


      <?php

      use App\model\Category;
      $cats = Category::all();
       ?>

      <div class="mainH">
    <div class="container fluid">
        <div class="tt-header-holder">
            <div class="tt-col-obj tt-obj-logo">
                <!-- logo -->
                <a class="tt-logo tt-logo-alignment" href="index.html">
                  <img src="../storage/app/avatar/logo.png" alt="a">
                </a>
                <!-- /logo -->
            </div>
            <div class="tt-col-obj tt-obj-search-type2">
                <div class="tt-search-type2">
                    <!-- tt-search -->
                    <form action="/search" method="get" role="search">
                        <input class="tt-search-input" type="search" placeholder="SEARCH PRODUCTS..." aria-label="SEARCH PRODUCTS..." autocomplete="off">
                        <button type="submit" class="tt-btn-search">SEARCH</button>
                        <div class="search-results" style="display: none;"></div>
                    </form>
                    <!-- /tt-search -->
                </div>
            </div>
            <div class="tt-col-obj obj-move-right">
                <!-- tt-langue and tt-currency -->
                <div class="tt-desctop-parent-multi tt-parent-box">
                    <div class="tt-multi-obj tt-dropdown-obj">
                        <button class="tt-dropdown-toggle" data-tooltip="Settings" data-tposition="bottom">
                            <i class="icon-f-79"></i>&nbsp;<span>Language</span>
                        </button>
                        <div class="tt-dropdown-menu">
                            <div class="tt-mobile-add">
                                <button class="tt-close">Close</button>
                            </div>
                            <div class="tt-dropdown-inner">
                                <ul>
                                    <li class="active"><a href="#">English</a></li>
                                    <li><a href="#">Arabic</a></li>

                                </ul>
                                <ul>
                                    <li class="active"><a href="#"><i class="icon-h-59"></i>USD - US Dollar</a></li>
                                    <li><a href="#"><i class="icon-h-60"></i>EUR - Euro</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /tt-langue and tt-currency -->
                <!-- tt-account -->
                <div class="tt-desctop-parent-account tt-parent-box">
                    <div class="tt-account tt-dropdown-obj">
                        <button class="tt-dropdown-toggle" data-tooltip="My Account" data-tposition="bottom">
                            <i class="icon-f-94"></i>&nbsp;<span>My Account</span>
                        </button>
                        <div class="tt-dropdown-menu">
                            <div class="tt-mobile-add">
                                <button class="tt-close">Close</button>
                            </div>
                            <div class="tt-dropdown-inner">
                                <ul>
                                    <li><a href="login.html"><i class="icon-f-94"></i>Account</a></li>
                                    <li><a href="wishlist.html"><i class="icon-n-072"></i>Wishlist</a></li>
                                    <li><a href="compare.html"><i class="icon-n-08"></i>Compare</a></li>
                                    <li><a href="page404.html"><i class="icon-f-68"></i>Check Out</a></li>
                                    <li><a href="login.html"><i class="icon-f-76"></i>Sign In</a></li>
                                    <li><a href="page404.html"><i class="icon-f-77"></i>Sign Out</a></li>
                                    <li><a href="create-account.html"><i class="icon-f-94"></i>Register</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /tt-account -->
                <!-- tt-cart -->
                <div class="tt-desctop-parent-cart tt-parent-box">
                    <div class="tt-cart tt-dropdown-obj" data-tooltip="Cart" data-tposition="bottom">
                        <button class="tt-dropdown-toggle">
                            <i class="icon-g-48"></i>&nbsp;<span>Cart</span>
                            <span class="tt-badge-cart">3</span>
                        </button>
                        <div class="tt-dropdown-menu">
                            <div class="tt-mobile-add">
                                <h6 class="tt-title">SHOPPING CART</h6>
                                <button class="tt-close">Close</button>
                            </div>
                            <div class="tt-dropdown-inner">
                                <div class="tt-cart-layout">
                                    <!-- layout emty cart -->
                                    <!-- <a href="empty-cart.html" class="tt-cart-empty">
            <i class="icon-f-39"></i>
            <p>No Products in the Cart</p>
          </a> -->
                                    <div class="tt-cart-content">
                                        <div class="tt-cart-list">
                                            <div class="tt-item">
                                                <a href="#">
                                                    <div class="tt-item-img">
                                                        <img src="images/loader.svg" data-src="images/product/product-01.jpg" alt="">
                                                    </div>
                                                    <div class="tt-item-descriptions">
                                                        <h2 class="tt-title">products</h2>
                                                        <ul class="tt-add-info">
                                                            <li>Yellow, Material 2, Size 58,</li>
                                                            <li>Vendor: Addidas</li>
                                                        </ul>
                                                        <div class="tt-quantity">1 X</div>
                                                        <div class="tt-price">$12</div>
                                                    </div>
                                                </a>
                                                <div class="tt-item-close">
                                                    <a href="#" class="tt-btn-close"></a>
                                                </div>
                                            </div>
                                            <div class="tt-item">
                                                <a href="#">
                                                    <div class="tt-item-img">
                                                        <img src="images/loader.svg" data-src="images/product/product-02.jpg" alt="">
                                                    </div>
                                                    <div class="tt-item-descriptions">
                                                        <h2 class="tt-title">products</h2>
                                                        <ul class="tt-add-info">
                                                            <li>Yellow, Material 2, Size 58,</li>
                                                            <li>Vendor: Addidas</li>
                                                        </ul>
                                                        <div class="tt-quantity">1 X</div>
                                                        <div class="tt-price">$18</div>
                                                    </div>
                                                </a>
                                                <div class="tt-item-close">
                                                    <a href="#" class="tt-btn-close"></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tt-cart-total-row">
                                            <div class="tt-cart-total-title">SUBTOTAL:</div>
                                            <div class="tt-cart-total-price">$324</div>
                                        </div>
                                        <div class="tt-cart-btn">
                                            <div class="tt-item">
                                                <a href="#" class="btn">PROCEED TO CHECKOUT</a>
                                            </div>
                                            <div class="tt-item">
                                                <a href="shopping_cart_02.html" class="btn-link-02 tt-hidden-mobile">View Cart</a>
                                                <a href="shopping_cart_02.html" class="btn btn-border tt-hidden-desctope">VIEW CART</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /tt-cart -->
            </div>
        </div>
    </div>
</div

        <!-- tt-desktop-header -->
        <div class="tt-desktop-header headerunderline">



            <div class="navH">
                <div class="container small-header">
                    <div class="tt-header-holder">
                        <div class="tt-col-obj tt-obj-menu-categories tt-desctop-parent-menu-categories">
                            <div class="tt-menu-categories">
                                <button class="tt-dropdown-toggle">
                                    CATEGORIES
                                </button>
                                <div class="tt-dropdown-menu">
                                    <nav>
                                        <ul>
                              <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <li class="dropdown megamenu">

                                            <a href="<?php echo e(route('product.show', $cat->id)); ?>"><?php echo e($cat->title_en); ?> </a>

                                          </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <!-- asdasdsadasd -->

                                        </ul>
                                    </nav>
                                </div>

                                <!-- ////////////////////////////////// -->
                            </div>
                        </div>
                        <div class="tt-col-obj tt-obj-menu">
                            <!-- tt-menu -->
                            <div class="tt-desctop-parent-menu tt-parent-box">
                                <div class="tt-desctop-menu">
                                    <nav>
                                        <ul>
                                          <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                      <li class="dropdown megamenu">

                                                          <a href="<?php echo e(route('product.show', $cat->id)); ?>"><?php echo e($cat->title_en); ?> </a>

                                                      </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <!-- /tt-menu -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="tt-stuck-nav">
            <div class="container">
                <div class="tt-header-row ">
                    <div class="tt-stuck-desctop-menu-categories"></div>
                    <div class="tt-stuck-parent-menu"></div>
                    <div class="tt-stuck-mobile-menu-categories"></div>
                    <div class="tt-stuck-parent-search tt-parent-box"></div>
                    <div class="tt-stuck-parent-cart tt-parent-box"></div>
                    <div class="tt-stuck-parent-account tt-parent-box"></div>
                    <div class="tt-stuck-parent-multi tt-parent-box"></div>
                </div>
            </div>
        </div>
    </header>


            <script src="js/jquery.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
            <script src="js/slick.min.js"></script>
            <script src="js/perfect-scrollbar.min.js"></script>
            <script src="js/panelmenu.js"></script>
            <script src="js/instafeed.min.js"></script>
            <script src="js/jquery.themepunch.tools.min.js"></script>
            <script src="js/jquery.themepunch.revolution.min.js"></script>
            <script src="js/jquery.plugin.min.js"></script>
            <script src="js/jquery.countdown.min.js"></script>
            <script src="js/lazyload.min.js"></script>
            <script src="js/main.js"></script>
            <!-- form validation and sending to mail -->
            <script src="js/jquery.form.js"></script>
            <script src="js/jquery.validate.min.js"></script>
            <script src="js/jquery.form-init.js"></script>
</body>

</html>
