<?php

//Category model
use App\model\Category;


$cat = Category::all();

echo $cat;


?>
