<title><?php echo $__env->yieldContent('title', 'Edit Brands'); ?></title>
<?php echo $__env->make('in-in-layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



        <div class="main-panel">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xs-offset-3 col-xs-6 col-xs-offset-3 add-brand-container">
                            <div class="add-brand-img">
                                <p> تعديل علامه تجاريه</p>
                            </div>
                            <div class="add-brand-form">



        <!-- start form ************************* -->
              <form action="<?php echo e(route('brand.update', $brand->id )); ?>" method="POST" enctype="multipart/form-data" class="form-group">
                       <input type="hidden" name="_method" value="PUT">
                       <?php echo e(csrf_field()); ?>


               <?php if($errors ->any() ): ?>
              <div class="bs-example text-center">

                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="alert alert-danger ">

                                 <strong>Warning! </strong> <?php echo e($error); ?>.

                            </div>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>


               <?php endif; ?>

                                    <input name="title_ar" value="<?php echo e($brand->title_ar); ?>" placeholder="الاسم بالعربي" type="text">
                                    <input name="title_en" value="<?php echo e($brand->title_en); ?>" name="title_en" placeholder="الاسم بالانجليزي" type="text">
                                    <input name="time" value="<?php echo e($brand->time); ?>" name="time"  placeholder="العنوان" type="time">

                                    <div class="add-brand-button" style="">
                                        <i class="fa fa-plus"></i>
                                        <button type="submit">تعديل</button>
                                    </div>
                      </form>


                            </div>

                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>

<?php echo $__env->make('in-in-layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
