<title><?php echo $__env->yieldContent('title', 'Show'); ?></title>
<?php echo $__env->make('in-layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div class="main-panel">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="card">
                            <div class="content table-responsive table-full-width">
                                <table class="table">
                                    <thead>
                                        <th>صورة القسم</th>
                                        <th>الاسم بالعربي</th>
                                        <th>الاسم بالانجليزي</th>
                                        <th>الوقت</th>
                                        <th>الناشر</th>
                                        
                                        


                                    </thead>
                                    <tbody>
                                    
                                        <tr>
                                            <td>
                                              <img style="width: 200px; height: 200px" src="../../storage/app/<?php echo e($cats -> image); ?>" >  
                                            </td>

                                            <td>
                                                <p><?php echo e($cats -> title_ar); ?></p>
                                            </td>
                                            <td>
                                                <p><?php echo e($cats -> title_en); ?></p>

                                            </td>

                                            <td>
                                                <p><?php echo e($cats -> time); ?></p>

                                            </td> 

                                            <td>
                                                <p><?php echo e($cats -> publisher); ?></p>

                                            </td>                                             

                                        </tr>
                                
                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>
                </div>
            </div>



        </div>
    </div>


<?php echo $__env->make('in-layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


