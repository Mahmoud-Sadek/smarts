<title><?php echo $__env->yieldContent('title', 'Category'); ?></title>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      <div class="content-inner">
          <div class="container-fluid">

              <div class="row">
                  <div class="col-xl-12">
                      <!-- Sorting -->
                      <div class="widget has-shadow">
                          <div class="widget-body">
                              <div class="table-responsive">
                                  <button onclick="" class="add-new"><a href="<?php echo e(url('/subcategory/create')); ?>">اضافة قسم فرعى جديد</a></button>

                                  <table id="sorting-table" class="table mb-0">
                                      <thead>
                                          <tr>
                                              <th>الصورة</th>
                                              <th>الاسم بالعربية</th>
                                              <th>الاسم بالانجليزية</th>
                                              <th>عدد الاقسام الفرعية</th>
                                              <th>تاريخ الاضافة</th>
                                              <th>الناشر</th>
                                              <th>Actions</th>
                                          </tr>
                                      </thead>
                                      <tbody>


 <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                              <td><img style="width:100px; height:100px" src="<?php echo e($cat->image); ?>"></td>
                                              <td><?php echo e($cat->title_ar); ?></td>
                                              <td><?php echo e($cat->title_en); ?></td>
                                              <td>3</td>
                                              <td><?php echo e($cat->time); ?></td>
                                              <td><?php echo e($cat->publisher); ?></td>
                                              <td class="td-actions">
                                                <a href="<?php echo e(route('subcategory.edit', $cat->id)); ?>"><i class="la la-edit edit"></i></a>
                                                  <form method="post" action="<?php echo e(route('subcategory.destroy', $cat->id)); ?>" style="display:inline">
                                                           <?php echo e(csrf_field()); ?>

                                                           <?php echo e(method_field('DELETE')); ?>


                                                     <button type="submit"><i class="la la-close delete"></i></button>
                                                  </form>
                                              </td>
                                          </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                      </tbody>
                                  </table>
                              </div>
                          </div>
                      </div>
                      <!-- End Sorting -->
                  </div>

              </div>
              <!-- End Row -->
          </div>
          <!-- End Container -->

      </div>
  </div>
  <!-- End Page Content -->
  </div>

<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
