<title><?php echo $__env->yieldContent('title', 'Category'); ?></title>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<ul class="nav navbar-left top-nav">
    <li>
           <a  href="<?php echo e(route('home')); ?>" class="btn btn-default">
               اضافه قسم جديد
           </a>
       </li>
</ul>
</div>
