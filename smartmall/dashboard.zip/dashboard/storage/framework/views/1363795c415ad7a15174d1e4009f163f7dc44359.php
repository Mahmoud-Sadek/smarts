

<title><?php echo $__env->yieldContent('title', 'Login'); ?></title>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="tt-pageContent">
	<div class="container-indent">
		<div class="container">
			<div class="text-right">
				<a href="index-ar.html" class="text-bold">
					العربية
				</a>
			</div>
			<div class="text-center">
				<a class="tt-logo tt-logo-alignment m-4" href="index.html"><img src="images/custom/logo.png" alt=""></a>
				<h3>Create your account</h3>
				<p class="mb-3">
					Do you have an account? <a href="login.html" class="log-in">Sign In</a>
				</p>
			</div>


			<div class="tt-login-form">
				<div class="row justify-content-center">
					<div class="col-md-8 col-lg-6">
						<div class="tt-item">
							<div class="form-default">

                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>



                        <div class="form-group row">

                                <input placeholder="Name" id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>




                        <div class="form-group row">

                                <input placeholder="E-mail" id="admin_email" type="email" class="form-control<?php echo e($errors->has('admin_email') ? ' is-invalid' : ''); ?>" name="admin_email" value="<?php echo e(old('admin_email')); ?>" required>

                                <?php if($errors->has('admin_email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('admin_email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>




                        <div class="form-group row">

                                <input placeholder="Password" id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>





                        <div class="form-group row">

                                <input placeholder="Comfirm Password" placeholder="Last Name" id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                        </div>




                        <div class="form-group">
                                <button type="submit" class="btn btn-block">
                                    <?php echo e(__('Sign Up')); ?>

                                </button>
                        </div>



                    </form>








        							</div>
        						</div>
        					</div>
        				</div>
        			</div>




        		</div>
        	</div>
        </div>


<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
