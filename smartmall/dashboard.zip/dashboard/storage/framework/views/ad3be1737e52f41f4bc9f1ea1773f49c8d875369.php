<title><?php echo $__env->yieldContent('title', 'Brands'); ?></title>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<div class="content-inner">
    <div class="container-fluid">

        <div class="row">
            <div class="col-xl-12">
                <!-- Sorting -->
                <div class="widget has-shadow">
                    <div class="widget-body">
                        <div class="table-responsive">
                            <button onclick="" class="add-new"><a href="<?php echo e(url('/brand/create')); ?>">اضافة علامة تجارية جديده</a></button>

                            <table id="sorting-table" class="table mb-0">
                                <thead>
                                    <tr>
                                        <th>صورة القسم</th>
                                        <th>الاسم بالعربي</th>
                                        <th>الاسم  بالانجليزية</th>
                                        <th>الناشر</th>
                                        <th>وقت الاضافة</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>

                                <tbody>

 <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><img style="width:150px; height:100px" src="storage/app/<?php echo e($brand->image); ?>"></td>
                                        <td><span class="text-primary"><?php echo e($brand->title_ar); ?></span></td>
                                        <td><?php echo e($brand->title_en); ?></td>
                                        <td><?php echo e($brand->publisher); ?></td>
                                        <td><?php echo e($brand->time); ?></td>
                                        <td class="td-actions">
                                          <a href="<?php echo e(route('brand.edit', $brand->id)); ?>"><i class="la la-edit edit"></i></a>
                                          <form method="post" action="<?php echo e(route('brand.destroy', $brand->id)); ?>" style="display:inline">
                                                   <?php echo e(csrf_field()); ?>

                                                   <?php echo e(method_field('DELETE')); ?>


                                             <button type="submit"><i class="la la-close delete"></i></button>
                                          </form>
                                        </td>
                                    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
                <!-- End Sorting -->
            </div>

        </div>
        <!-- End Row -->
    </div>
    <!-- End Container -->

    <a href="#" class="go-top"><i class="la la-arrow-up"></i></a>

</div>
</div>
<!-- End Page Content -->
</div>






<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
