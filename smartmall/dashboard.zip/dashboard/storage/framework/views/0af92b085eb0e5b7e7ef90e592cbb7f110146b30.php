<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>MATJARI</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="shortcut icon" href="favicon.jpg">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="css/slick.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/theme.css">
</head>
<body>



	<div class="container">
		<div class="row">
			<nav aria-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="#">Home</a></li>
					<li class="breadcrumb-item"><a href="#">Electronics</a></li>
					<li class="breadcrumb-item active" aria-current="page">Mobile</li>
				</ol>
			</nav>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-3 col-sm-4">
				<div class="Filltering">

					<div class="accordion" id="accordionExample">
						<div class="card">
							<div class="card-header" id="headingOne">
								<h2 class="mb-0">
									<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
										Category <span class="icon-e-13"></span>
									</button>
								</h2>
							</div>

							<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
								<div class="card-body">
									<nav class="nav flex-column">
										<a class="nav-link active" href="#">
											Electronics & Mobiles
											<span>
												185
											</span>
										</a>
										<nav class="nav flex-column">
											<a class="nav-link active" href="#">
												Portable Bluetooth Speakers
												<span>
													100
												</span>
											</a>
											<a class="nav-link active" href="#">
												Computer Speakers
												<span>
													100
												</span>
											</a>
											<a class="nav-link active" href="#">
												Home Entertainment
												<span>
													100
												</span>
											</a>
											<a class="nav-link active" href="#">
												Home Entertainment
												<span>
													100
												</span>
											</a>
											<a class="nav-link active" href="#">
												Multimedia Speakers
												<span>
													100
												</span>
											</a>
											<a class="nav-link active" href="#">
												Portable Audio & Video
												<span>
													100
												</span>
											</a>
											<a class="nav-link active" href="#">
												Accessories & Supplies
												<span>
													100
												</span>
											</a>
										</nav>
										<a class="nav-link" href="#">
											Automotive
											<span>
												100
											</span>
										</a>

										<nav class="nav flex-column">
											<a class="nav-link active" href="#">
												Car Audio
												<span>
													100
												</span>
											</a>
										</nav>
									</nav>
								</div>
							</div>
						</div>





						<!-- <div class="card">
							<div class="card-header" id="headingTwo">
								<h2 class="mb-0">
									<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
										Fulfillment <span class="icon-e-13"></span>
									</button>
								</h2>
							</div>
							<div id="collapseTwo" class="" aria-labelledby="headingTwo" data-parent="#accordionExample">
								<div class="card-body">
									<form>
										<div class="custom-control custom-checkbox">
											<input type="checkbox" class="custom-control-input" id="customCheck1">
											<label class="custom-control-label" for="customCheck1">
												<img src="images/p/now.svg" alt="" class="nowlable loading" data-was-processed="true">
											</label>
										</div>
									</form>
								</div>
							</div>
						</div>



						<div class="card">
							<div class="card-header" id="headingThree">
								<h2 class="mb-0">
									<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
										Price (AED) <span class="icon-e-13"></span>
									</button>
								</h2>
							</div>
							<div id="collapseThree" class="" aria-labelledby="headingThree" data-parent="#accordionExample">
								<div class="card-body">
									<form class="pricelevel">
										<div class="form-group row">
											<input class="form-control form-control-sm col-4" type="number">
											<label for="exampleFormControlFile1" class="col-2">TO</label>
											<input class="form-control form-control-sm col-4" type="number">
											<a class="col-2">GO</a>
										</div>
									</form>
								</div>
							</div>
						</div>



						<div class="card">
							<div class="card-header" id="headingFour">
								<h2 class="mb-0">
									<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
										Connectivity <span class="icon-e-13"></span>
									</button>
								</h2>
							</div>
							<div id="collapseFour" class="" aria-labelledby="headingFour" data-parent="#accordionExample">
								<div class="card-body">
									<form>
										<div class="custom-control custom-checkbox">
											<input type="checkbox" class="custom-control-input" id="customCheck2">
											<label class="custom-control-label" for="customCheck2">
												Bluetooth/Wireless <span>87</span>
											</label>
										</div>
										<div class="custom-control custom-checkbox">
											<input type="checkbox" class="custom-control-input" id="customCheck3">
											<label class="custom-control-label" for="customCheck3">
												Wired <span>87</span>
											</label>
										</div>
									</form>
								</div>
							</div>
						</div> -->

					</div>
				</div>
			</div>
<?php

use App\model\Product;
use App\model\Brand;

$Products = Product::paginate(3);
$brands = Brand::all();

?>


			<div class="col-md-9 col-sm-8 ">
				<div class="col-md-12">
					<h5 class="float-left">
						<span class="itemsNo">1281</span> results found for "<span class="catname">Mobile</span>"
					</h5>
					<div class="float-right">
						<form class="sortfilter">
							<div class="input-group mb-3">
								<div class="input-group-prepend">
									<label class="input-group-text" for="inputGroupSelect01">SORT BY</label>
								</div>
								<select class="custom-select" id="inputGroupSelect01">
									<option selected>Popularity</option>
									<option value="1">One</option>
									<option value="2">Two</option>
									<option value="3">Three</option>
								</select>
							</div>
							<div class="input-group mb-3">
								<div class="input-group-prepend">
									<label class="input-group-text" for="inputGroupSelect01">DISPLAY</label>
								</div>
								<select class="custom-select" id="inputGroupSelect01">
									<option selected>50 per page</option>
									<option value="1">One</option>
									<option value="2">Two</option>
									<option value="3">Three</option>
								</select>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-12 MATJARIPRO">


<?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="col-md-3">
						<div class="ProItem">
				    		<a class="" href="">
				    			<div class="proimage">
				    				<div class="">
                      <img src="../storage/app/<?php echo e($Product->image1); ?>" alt="a">
				    				</div>

				    				<div class="actionContainer">
				    					<button aria-label="Add To wishlist" class="actionBtn">
				    						<i class="icon-h-13"></i>
				    					</button>
					    			</div>
					    		</div>
					    		<div class="prodetails">
				    				<p class="brand">
                        wating ...
					    			</p>
				    				<div class="name" style="overflow: hidden;">
										<p>
                      <?php echo e($Product->name_en); ?>

            				</p>
				    				</div>
				    				<div class="priceRow">
				    					<div class="productPriceContainer">
				    						<p class="proPrice">
			    								<span class="preReductionPrice">
				    								<?php echo e($Product->price); ?>

				    							</span>
				    							<span class="discount">
					    							<span class="discountBadge">
					    								<?php echo e($Product->offer_price); ?>

					    							</span>
				    							</span>
				    							<span class="sellingPrice">
					    							<?php echo e($Product->price); ?>

					    						</span>
					    					</p>
					    				</div>
					    				<div class="actionContainer">
					    					<button aria-label="Add To Cart" class="actionBtn">
					    						<i class="icon-g-48"></i>
					    					</button>
					    				</div>
					    			</div>
					    		</div>
					    	</a>
					    </div>


					</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

				<div class="col-md-12">
            <?php echo e($Products ->links()); ?>

		   	</div>






  <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/slick.min.js"></script>
    <script src="js/perfect-scrollbar.min.js"></script>
    <script src="js/panelmenu.js"></script>
    <script src="js/instafeed.min.js"></script>
    <script src="js/jquery.themepunch.tools.min.js"></script>
    <script src="js/jquery.themepunch.revolution.min.js"></script>
    <script src="js/jquery.plugin.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/lazyload.min.js"></script>
    <script src="js/main.js"></script>
    <!-- form validation and sending to mail -->
    <script src="js/jquery.form.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/jquery.form-init.js"></script>
</body>
</html>
