<title><?php echo $__env->yieldContent('title', 'orders'); ?></title>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>






<!-- End Left Sidebar -->
<div class="content-inner">
    <div class="container-fluid">
        <div class="row flex-row">
            <div class="col-xl-12">
                <!-- Begin Widget 07 -->
                <div class="widget widget-07 has-shadow">
                    <!-- Begin Widget Body -->
                    <div class="widget-body">
                        <div class="table-responsive table-scroll padding-right-10" style="max-height:520px;">
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>
                                            <div class="styled-checkbox mt-2">
                                                <input type="checkbox" name="check-all" id="check-all">
                                                <label for="check-all"></label>
                                            </div>
                                        </th>
                                        <th>Order ID</th>
                                        <th>Vendor Name</th>
                                        <th>Country</th>
                                        <th>Ship Date</th>
                                        <th><span style="width:100px;">Status</span></th>
                                        <th>Order Total</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>

<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td style="width:5%;">
                                            <div class="styled-checkbox mt-2">
                                                <input type="checkbox" name="cb3" id="cb3">
                                                <label for="cb3"></label>
                                            </div>
                                        </td>
                                        <td><span class="text-primary"><?php echo e($orders->id); ?></span></td>
                                        <td><?php echo e($orders->user2->name); ?></td>
                                        <td>KSA</td>
                                        <td><?php echo e($orders->time); ?></td>
                                        <td><span style="width:100px;"><span class="badge-text badge-text-small danger"><?php echo e($orders->status); ?></span></span></td>
                                        <td>$107.55</td>
                                        <td class="td-actions">
                                            <a href="#"><i class="la la-edit edit"></i></a>
                                            <form method="post" action="<?php echo e(route('order.destroy', $orders->id)); ?>" style="display:inline">
                                                     <?php echo e(csrf_field()); ?>

                                                     <?php echo e(method_field('DELETE')); ?>


                                               <button type="submit"><i class="la la-close delete"></i></button>
                                            </form>
                                        </td>
                                    </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- End Widget Body -->

                </div>
                <!-- End Widget 07 -->
            </div>
        </div>


    </div>

</div>
<!-- End Page Content -->
</div>
</div>










<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
