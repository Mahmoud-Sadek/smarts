<title><?php echo $__env->yieldContent('title', 'Admins'); ?></title>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


            <div class="content-inner">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-xl-12">
                            <!-- Sorting -->
                            <div class="widget has-shadow">
                                <div class="widget-body">
                                    <div class="table-responsive">
                                        <button onclick="" class="add-new"><a href="<?php echo e(url('/admin/create')); ?>">اضافة مورد جديد</a></button>

                                        <table id="sorting-table" class="table mb-0">
                                            <thead>
                                                <tr>
                                                    <th>الاسم</th>
                                                    <th>البريد الالكتروني</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>


<?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($admin->name); ?></td>
                                                    <td><?php echo e($admin->admin_email); ?></td>
                                                    <td class="td-actions">
                                                      <form method="post" action="<?php echo e(route('admin.destroy', $admin->id)); ?>" style="display:inline">
                                                               <?php echo e(csrf_field()); ?>

                                                               <?php echo e(method_field('DELETE')); ?>


                                                         <button type="submit"><i class="la la-close delete"></i></button>
                                                      </form>
                                                    </td>
                                                </tr>


 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- End Sorting -->
                        </div>

                    </div>
                    <!-- End Row -->
                </div>
                <!-- End Container -->

            </div>
        </div>
        <!-- End Page Content -->
    </div>



<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
