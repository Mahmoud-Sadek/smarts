<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>MATJARI</title>
	<meta name="keywords" content="">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="shortcut icon" href="favicon.jpg">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="css/slick.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/theme.css">
</head>
<body>














<div class="container">
	<div class="addons">
		<a href="">
			<img src="../storage/app/avatar/gif/b-0.png" alt="a">
		</a>
	</div>
	<div class="row no-gutters">
		<div class="col-6 mb-4">
			<a href="">
				<img src="../storage/app/avatar/gif/b-0.png" alt="a">
			</a>
		</div>
		<div class="col-6 mb-4">
			<a href="">
				<img src="../storage/app/avatar/gif/b-0.png" alt="a">
			</a>
		</div>
		<div class="col-6 mb-4">
			<a href="">
				<img src="../storage/app/avatar/gif/b-0.png" alt="a">
			</a>
		</div>
		<div class="col-6 mb-4">
			<a href="">
				<img src="../storage/app/avatar/gif/b-0.png" alt="a">
			</a>
		</div>
		<div class="col-6 mb-4">
			<a href="">
				<img src="../storage/app/avatar/gif/b-0.png" alt="a">
			</a>
		</div>
		<div class="col-6 mb-4">
			<a href="">
				<img src="../storage/app/avatar/gif/b-0.png" alt="a">
			</a>
		</div>
	</div>

	<div class="row BG-C p-3 ">
		<div class="col-12">
			<h5>
				Explore More
			</h5>
		</div>
		<div class="col mb-4 text-center">
			<a href="">
				<img src="../storage/app/avatar/gif/b-0.png" alt="a">
				<p class="lead">
					Decorations
				</p>
			</a>
		</div>
		<div class="col mb-4 text-center">
			<a href="">
				<img src="../storage/app/avatar/gif/b-1.png" alt="a">
				<p class="lead">
					Bedding
				</p>
			</a>
		</div>
		<div class="col mb-4 text-center">
			<a href="">
				<img src="../storage/app/avatar/gif/b-1.png" alt="a">
				<p class="lead">
					Gifts
				</p>
			</a>
		</div>
		<div class="col mb-4 text-center">
			<a href="">
				<img src="../storage/app/avatar/gif/b-1.png" alt="a">
				<p class="lead">
					Toys
				</p>
			</a>
		</div>
		<div class="col mb-4 text-center">
			<a href="">
				<img src="../storage/app/avatar/gif/b-1.png" alt="a">
				<p class="lead">
					Kids Fashion
				</p>
			</a>
		</div>
	</div>
	<div class="addons">
		<a href="">
			<img src="../storage/app/avatar/gif/b-1.png" alt="a">
		</a>
	</div>
</div>





<a href="#" class="tt-back-to-top">BACK TO TOP</a>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/perfect-scrollbar.min.js"></script>
<script src="js/panelmenu.js"></script>
<script src="js/instafeed.min.js"></script>
<script src="js/jquery.themepunch.tools.min.js"></script>
<script src="js/jquery.themepunch.revolution.min.js"></script>
<script src="js/jquery.plugin.min.js"></script>
<script src="js/jquery.countdown.min.js"></script>
<script src="js/lazyload.min.js"></script>
<script src="js/main.js"></script>
<!-- form validation and sending to mail -->
<script src="js/jquery.form.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/jquery.form-init.js"></script>
</body>
</html>
