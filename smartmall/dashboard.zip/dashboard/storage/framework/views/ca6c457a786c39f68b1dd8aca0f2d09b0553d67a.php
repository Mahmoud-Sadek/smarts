

<title><?php echo $__env->yieldContent('title', 'Categories'); ?></title>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>





<div id="loader-wrapper">
	<div id="loader">
		<div class="dot"></div>
		<div class="dot"></div>
		<div class="dot"></div>
		<div class="dot"></div>
		<div class="dot"></div>
		<div class="dot"></div>
		<div class="dot"></div>
	</div>
</div>



<div id="tt-pageContent">
	<div class="container-indent">
		<div class="container">




			<div class="text-right">
				<a href="index-ar.html" class="text-bold">
					العربية
				</a>
			</div>

			<div class="text-center">
				<a class="tt-logo tt-logo-alignment m-4" href="index.html"><img src="images/custom/logo.png" alt=""></a>
				<p class="mb-3">
					Welcome back!
				</p>
				<h3>Sign in to your account</h3>
				<p class="mb-3">
					Don’t have an account? <a href="create-account.html" class="log-in">Sign up</a>
				</p>
			</div>


			<div class="tt-login-form">
				<div class="row justify-content-center">
					<div class="col-md-8 col-lg-6">
						<div class="tt-item">
							<div class="form-default">



								<form id="contactform Myform" method="post" novalidate="novalidate">
									<div class="form-group">
										<input type="text" name="email" class="form-control" id="loginInputEmail" placeholder="E-mail">
									</div>
									<div class="form-group">
										<input type="text" name="passowrd" class="form-control" id="loginInputPassword" placeholder="Password">
									</div>
									<div class="form-group">
										<a href="" class="log-in d-block text-center mb-2">Forgot your password</a>
										<button class="btn btn-block" type="submit">SIGN IN</button>
									</div>
								</form>




							</div>
						</div>
					</div>
				</div>
			</div>






		</div>
	</div>
</div>



<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
