<title><?php echo $__env->yieldContent('title', 'Add Category'); ?></title>
<?php echo $__env->make('in-layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<?php

use App\model\Category;

$cats = Category::all();


?>





        <div class="main-panel">

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xs-offset-3 col-xs-6 col-xs-offset-3 add-cat-container">
                            <div class="add-cat-img">
                                <p>اضافة قسم</p>
                            </div>
                            <div class="add-cat-form">





       <!-- start form ************************* -->
             <form style="width: 50%" action="<?php echo e(route('category.store')); ?>" method="POST" enctype="multipart/form-data" class="form-group">

                <?php echo e(csrf_field()); ?>


              <?php if($errors ->any() ): ?>
                     <div class="bs-example text-center">

                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                           <div class="alert alert-danger ">

                                <strong>Warning! </strong> <?php echo e($error); ?>.

                           </div>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>


              <?php endif; ?>

              <div style="position: relative; text-align: center; margin: 30px 0" class="profile-img">
                    <div class="file-upload">
                        <label for="upload" class="file-upload__label"> <img class="small" src="../../storage/app/avatar/plus2.ico"> </label>
                        <input id="upload" class="file-upload__input" type="file" name="file-upload">
                    </div>


                </div>


                                <div style="position: relative; text-align: center; margin: 30px 0" class="profile-img">

                                </div>


                                <input name="name_ar" placeholder="الاسم بالعربي" type="text" >
                                <input name="name_en" placeholder="الاسم بالانجليزي" type="text" >
                                <select class="" name="parent_id">
                                  <option value="0">None</option>
                                   <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->title_en); ?></option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input name="time" type="time" >


				                  <div class="form-group">
				                        <b>Add Image:  </b>
				                     <input   name="cat_image" type="file" />


				                   </div>


                                <div class="add-cat-button" style="">
                                    <i class="fa fa-plus"></i>
                                    <button  type="submit">اضافة</button>
                                </div>


               </form>


                            </div>

                        </div>
                    </div>
                </div>
            </div>


        </div>


    </div>









<?php echo $__env->make('in-layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
