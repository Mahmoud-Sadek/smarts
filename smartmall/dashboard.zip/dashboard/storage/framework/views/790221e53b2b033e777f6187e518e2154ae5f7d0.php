<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title> Add admin</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link href="../css/bootstrap.min.css" rel="stylesheet" />
    <link href="../css/animate.min.css" rel="stylesheet" />
    <link href="../css/dashboard.css?v=1.4.0" rel="stylesheet" />
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>

</head>

<body>

    <div class="wrapper">
        <!-- Navigation -->

        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header" style="float: right">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="dashboard.html">
                    <h1 class="text-center">متجري</h1>
                </a>
            </div>
            <!-- Top Menu Items -->




            <ul style="visibility: hidden;" class="nav navbar-left top-nav">
             <li>
                    <a  href="add-admin.html" class="btn btn-default">
                        ااضافه
                    </a>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
              <ul class="nav navbar-nav side-nav">



                  <li>
                       <a href="<?php echo e(route('category.index')); ?>" data-toggle="collapse" data-target="#submenu-2">

                          الاقسام
                   <i class="fa fa-columns"></i>
                      </a>
  <!--
                      <ul id="submenu-2" class="collapse">
                          <li><a href="cat.html">الاقسام الرئيسية <i class="fa fa-angle-double-left"></i></a></li>
                          <li><a href="subcat.html"> الاقسام الفرعية <i class="fa fa-angle-double-left"></i></a></li>
                      </ul>
  -->
                  </li>


                  <li>
                      <a href="<?php echo e(route('product.index')); ?>">

                          المنتجات

                          <i class="fa fa-money" aria-hidden="true"></i>
                      </a>
                  </li>
                  <li>
                      <a href="<?php echo e(route('offer.index')); ?>">
                          العروض


                          <i class="fa fa-gift" aria-hidden="true"></i>

                      </a>
                  </li>
                  <li>
                      <a href="<?php echo e(route('admin.index')); ?>">
                          المسئولين


                          <i class="fa fa-gift" aria-hidden="true"></i>

                      </a>
                  </li>
                  <li>
                      <a href="<?php echo e(route('brand.index')); ?>">
                          العلامات التجارية


                          <i class="fa fa-gift" aria-hidden="true"></i>

                      </a>
                  </li>

                  <li>


                        <?php if(auth()->guard()->guest()): ?>
                            <li>
                                <a  href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>



                                <a href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('تسجيل خروج')); ?> <i class="fas fa-sign-out-alt nav_icon"></i>
                                </a>



                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>

                                    </form>


                        <?php endif; ?>
                  </li>
                  
              </ul>
            </div>

            <!-- /.navbar-collapse -->
        </nav>
