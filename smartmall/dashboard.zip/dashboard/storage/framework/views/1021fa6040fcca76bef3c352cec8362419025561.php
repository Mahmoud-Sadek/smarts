<title><?php echo $__env->yieldContent('title', 'Category'); ?></title>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

     <ul class="nav navbar-left top-nav">
         <li>
                <a  href="<?php echo e(route('category.create')); ?>" class="btn btn-default">
                    اضافه قسم جديد
                </a>
            </li>
     </ul>
  </div>
         


        <!-- /.navbar-collapse -->
    </nav>




        <div class="main-panel">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="card">
                            <div class="content table-responsive table-full-width">
                                <table class="table">
                                    <thead>
                                        
                                        <th>الاسم بالعربي</th>
                                        <th>الاسم بالانجليزي</th>
                                        <th>Action</th>


                                    </thead>
                                    <tbody>
                               <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                    
                                            <td>
                                                <p><?php echo e($cat->title_ar); ?></p>
                                            </td>

                                            <td>
                                                <p><?php echo e($cat->title_en); ?></p>
                                            </td>

                                            <td>
                                                 <div>
   <a href="<?php echo e(route('category.edit', $cat->id)); ?>"  class="btn btn-success" >تعديل</a>

     <a href="<?php echo e(route('category.show', $cat->id)); ?>"  class="btn btn-primary" >عرض</a>


                                     <form method="post" action="<?php echo e(route('category.destroy', $cat->id)); ?>" style="display:inline">
                                              <?php echo e(csrf_field()); ?>

                                              <?php echo e(method_field('DELETE')); ?>

                                        <button   class="btn btn-danger">مسح</button>
                                     </form>
                                                    
                                                    </div>
                                            </td>

                                        </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>
                </div>
            </div>



        </div>
    </div>

<script>
    


<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


