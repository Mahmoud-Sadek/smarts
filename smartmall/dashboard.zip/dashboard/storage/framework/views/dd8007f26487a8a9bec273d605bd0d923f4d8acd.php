<?php echo $__env->make('in-layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<div class="content-inner">
    <div class="container-fluid">
        <div class="row flex-row">
            <div class="col-12">
                <div class="row d-flex align-items-center mb-5">

                    <div class="col-lg-12">

  <form method="POST" action="<?php echo e(route('admin.store')); ?>" >

                          <?php echo e(csrf_field()); ?>


                         <?php if($errors ->any() ): ?>
                                <div class="bs-example text-center">

                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                      <div class="alert alert-danger ">

                                           <strong>Warning! </strong> <?php echo e($error); ?>.

                                      </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </div>


                         <?php endif; ?>


                        <div class="mt-5 mb-5 position-relative">
                            <div class="group material-input">
                                <input name="name" type="text" required>
                                <span class="highlight"></span>
                                <span class="bar"></span>
                                <label>الاسم</label>
                            </div>
                        </div>


                        <div class="mt-5 mb-5 position-relative">
                            <div class="group material-input">
                                <input name="admin_email" type="email" required>
                                <span class="highlight"></span>
                                <span class="bar"></span>
                                <label>البريد الالكتروني</label>
                            </div>
                        </div>


                        <div class="mt-5 mb-5 position-relative">
                            <div class="group material-input">
                                <input name="password" type="password" required>
                                <span class="highlight"></span>
                                <span class="bar"></span>
                                <label>كلمة المرور</label>
                            </div>
                        </div>

                   <button type="submit" class="add text-center">إضافة</button>

             </form>

                    </div>
                </div>

            </div>
        </div>
        <!-- End Row -->
    </div>
    <!-- End Container -->

    <a href="#" class="go-top"><i class="la la-arrow-up"></i></a>

</div>







<?php echo $__env->make('in-layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
