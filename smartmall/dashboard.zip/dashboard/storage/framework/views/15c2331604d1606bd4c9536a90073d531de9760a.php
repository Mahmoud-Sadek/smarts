<title><?php echo $__env->yieldContent('title', 'Add Brands'); ?></title>
<?php echo $__env->make('in-layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



        <div class="main-panel">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xs-offset-3 col-xs-6 col-xs-offset-3 add-brand-container">
                            <div class="add-brand-img">
                                <p>اضافة علامة تجارية</p>
                            </div>
                            <div class="add-brand-form">



              <!-- start form ************************* -->
                    <form style="width: 50%" action="<?php echo e(route('brand.store')); ?>" method="POST" enctype="multipart/form-data" class="form-group">

                      <?php echo e(csrf_field()); ?>


                     <?php if($errors ->any() ): ?>
                            <div class="bs-example text-center">

                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                  <div class="alert alert-danger ">

                                       <strong>Warning! </strong> <?php echo e($error); ?>.

                                  </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </div>


                     <?php endif; ?>
                     <div style="position: relative; text-align: center; margin: 30px 0" class="profile-img">
                           <div class="file-upload">
                               <label for="upload" class="file-upload__label"> <img class="small" src="../../storage/app/avatar/plus2.ico"> </label>
                               <input id="upload" class="file-upload__input" type="file" name="file-upload">
                           </div>


                       </div>

                                    <input name="title_ar" placeholder="الاسم بالعربي" type="text">
                                    <input name="title_en" placeholder="الاسم بالانجليزي" type="text">
                                    <input name="time"  placeholder="العنوان" type="time">

                                    <div class="add-brand-button" style="">
                                        <i class="fa fa-plus"></i>
                                        <button type="submit">اضافة</button>
                                    </div>
                      </form>


                            </div>

                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>

<?php echo $__env->make('in-layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
