<title><?php echo $__env->yieldContent('title', 'Brands'); ?></title>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<ul class="nav navbar-left top-nav">
    <li>
           <a  href="<?php echo e(route('brand.create')); ?>" class="btn btn-default">
               اضافه ماركه
           </a>
       </li>
</ul>
</div>



   <!-- /.navbar-collapse -->
</nav>




        <div class="main-panel">



            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <table class="table">
                            <thead>
                                <th>الاسم بالعربي</th>
                                <th>الاسم بالانجليزي</th>
                                <th>الوقت</th>
                                <th>Action</th>


                            </thead>
                            <tbody>
               <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <p><?php echo e($brand->title_ar); ?></p>
                                    </td>
                                    <td>
                                        <p><?php echo e($brand->title_en); ?></p>
                                    </td>

                                    <td>
                                        <p><?php echo e($brand->time); ?></p>
                                    </td>

                                    <td>
                                        <div>

                                          <a href="<?php echo e(route('brand.edit', $brand->id)); ?>"  class="btn btn-success" >تعديل</a>

                                            <form method="post" action="<?php echo e(route('brand.destroy', $brand->id)); ?>" style="display:inline">
                                                     <?php echo e(csrf_field()); ?>

                                                     <?php echo e(method_field('DELETE')); ?>

                                               <button   class="btn btn-danger">مسح</button>
                                            </form>
                                        </div>
                                    </td>



                                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>


        </div>
    </div>



<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
