<?php echo $__env->make('in-layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <?php

  use App\model\Category;
  use App\model\Brand;
  use App\model\Offer;

  $cats       = Category::where('parent_id','=', 0)->get();
  $categories = Category::where('parent_id','!=', 0)->get();
  $brands = Brand::all();
  $offers = Offer::all();


  ?>


  <div class="content-inner">
      <div class="container-fluid">
          <div class="row flex-row">
              <div class="col-12">
                  <div class="row d-flex align-items-center mb-5">

                      <div class="col-lg-12">

        <!-- start form ************************* -->
              <form action="<?php echo e(route('product.store')); ?>" method="POST" enctype="multipart/form-data" class="form-group">

                 <?php echo e(csrf_field()); ?>


               <?php if($errors ->any() ): ?>
                      <div class="bs-example text-center">

                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="alert alert-danger ">

                                 <strong>Warning! </strong> <?php echo e($error); ?>.

                            </div>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>


               <?php endif; ?>

                          <label for="file-upload" class="custom-file-upload">
                              <i class="la la-lg la-cloud-upload"></i> &nbsp;
                              تحميل صورة
                          </label>
                          <input name="image1" id="file-upload" type="file" />


                          <label for="file-upload" class="custom-file-upload">
                              <i class="la la-lg la-cloud-upload"></i> &nbsp;
                              تحميل صورة
                          </label>
                          <input name="image12" id="file-upload" type="file" />



                          <br><br>



                          <div class="mt-5 mb-5 position-relative">
                              <div class="group material-input">
                                  <input name="name_ar" type="text" required>
                                  <span class="highlight"></span>
                                  <span class="bar"></span>
                                  <label>الاسم بالعربي</label>
                              </div>
                          </div>


                          <div class="mt-5 mb-5 position-relative">
                              <div class="group material-input">
                                  <input name="name_en" type="text" required>
                                  <span class="highlight"></span>
                                  <span class="bar"></span>
                                  <label>الاسم بالانجليزي</label>
                              </div>
                          </div>



                          <div class="form-group row mb-5">
                              <label class="col-lg-3 form-control-label">اسم القسم الاساسي</label>
                              <div class="col-lg-9 select mb-3">
                                  <select name="cat_id" class="custom-select form-control">

                                      <option disabled value="0">Category</option>
                                      <option value="0">None</option>

                                      <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->title_en); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                  </select>
                              </div>
                          </div>


                          <div class="form-group row mb-5">
                              <label class="col-lg-3 form-control-label">اسم القسم الفرعى </label>
                              <div class="col-lg-9 select mb-3">
                                  <select name="son_id" class="custom-select form-control">


                                        <option disabled value="0">SubCategory</option>
                                        <option value="0">None</option>

                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->title_en); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                  </select>
                              </div>
                          </div>


                          <div class="form-group row mb-5">
                              <label class="col-lg-3 form-control-label">اسم ا</label>
                              <div class="col-lg-9 select mb-3">
                                  <select name="brand_id" class="custom-select form-control">

                                    <option disabled value="0">Brands</option>

                                      <option value="0">None</option>

                                      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->title_en); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                              </div>
                          </div>



                          <div class="form-group row mb-5">
                              <label class="col-lg-3 form-control-label">اسم القسم الاساسي بالانجليزي</label>
                              <div class="col-lg-9 select mb-3">
                                  <select name="offer_id" class="custom-select form-control">

                                    <option disabled value="0">Offers</option>
                                    <option value="0">None</option>

                                    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($offer->id); ?>"><?php echo e($offer->title_en); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                  </select>
                              </div>
                          </div>





                          <div class="mt-5 mb-5 position-relative">
                              <div class="group material-input">
                                  <input name="price" type="text" required>
                                  <span class="highlight"></span>
                                  <span class="bar"></span>
                                  <label>السعر الاصلي</label>
                              </div>
                          </div>



                          <div class="mt-5 mb-5 position-relative">
                              <div class="group material-input">
                                  <input name="offer_price" type="text" required>
                                  <span class="highlight"></span>
                                  <span class="bar"></span>
                                  <label>نسبة الخصم</label>
                              </div>
                          </div>



                          <div class="mt-5 mb-5 position-relative">
                              <div class="group material-input">
                                  <input name="quantity" type="text" required>
                                  <span class="highlight"></span>
                                  <span class="bar"></span>
                                  <label>الكمية</label>
                              </div>
                          </div>



                          <div class="mt-5 mb-5 position-relative">
                              <div class="group material-input">
                                  <textarea name="detail_ar" class="form-control" name="name" rows="8" cols="80" required></textarea>
                                  <span class="highlight"></span>
                                  <span class="bar"></span>
                                  <label>الوصف بالعربي</label>
                              </div>
                          </div>


                          <div class="mt-5 mb-5 position-relative">
                              <div class="group material-input">
                                  <textarea name="detail_en" class="form-control" name="name" rows="8" cols="80" required></textarea>
                                  <span class="highlight"></span>
                                  <span class="bar"></span>
                                  <label>الوصف بالانجليزي</label>
                              </div>
                          </div>


                          <div class="mt-5 mb-5 position-relative">
                              <div class="group material-input">
                                  <textarea name="infromation_ar" class="form-control" name="name" rows="8" cols="80" required></textarea>
                                  <span class="highlight"></span>
                                  <span class="bar"></span>
                                  <label>المعلومات بالعربي</label>
                              </div>
                          </div>


                          <div class="mt-5 mb-5 position-relative">
                              <div class="group material-input">
                                  <textarea name="infromation_en" class="form-control" name="name" rows="8" cols="80" required></textarea>
                                  <span class="highlight"></span>
                                  <span class="bar"></span>
                                  <label>المعلومات بالانجليزي</label>
                              </div>
                          </div>

                          <div class="form-group row mb-5">
                              <label class="col-lg-3 form-control-label">وقت الاضافة</label>
                              <div class="col-lg-9 mb-3">
                                  <input name="time" type="datetime-local" name="bdaytime" required>
                              </div>
                          </div>



                          <button type="submit" class="add text-center">إضافة</button>

                 </form>

                      </div>
                  </div>

              </div>
          </div>
          <!-- End Row -->
      </div>
      <!-- End Container -->

      <a href="#" class="go-top"><i class="la la-arrow-up"></i></a>

  </div>




<?php echo $__env->make('in-layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
