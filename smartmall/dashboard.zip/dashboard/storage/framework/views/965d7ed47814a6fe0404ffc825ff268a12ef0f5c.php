<?php

// //Category model
// use App\model\Brand;
//
//
// $brand = Brand::all();
//
// echo $brand;
//
//
// ?>
