<?php

//Category model
// use App\model\Product;
//
//
// $product = Product::all();
//
// echo $product;
//

?>
