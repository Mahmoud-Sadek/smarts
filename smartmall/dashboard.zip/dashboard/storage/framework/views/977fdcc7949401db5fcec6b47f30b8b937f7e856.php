<title><?php echo $__env->yieldContent('title', 'Edit Category'); ?></title>
<?php echo $__env->make('in-in-layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>









        <div class="main-panel">

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xs-offset-3 col-xs-6 col-xs-offset-3 add-cat-container">
                            <div class="add-cat-img">
                                <p>تعديل قسم</p>
                            </div>
                            <div class="add-cat-form">




       <!-- start form ************************* -->
             <form action="<?php echo e(route('category.update', $cats->id )); ?>" method="POST" enctype="multipart/form-data" class="form-group">
                      <input type="hidden" name="_method" value="PUT">
                      <?php echo e(csrf_field()); ?>


              <?php if($errors ->any() ): ?>
                     <div class="bs-example text-center">

                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                           <div class="alert alert-danger ">

                                <strong>Warning! </strong> <?php echo e($error); ?>.

                           </div>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>


              <?php endif; ?>


                      <?php echo e(csrf_field()); ?>

                                <div style="position: relative; text-align: center; margin: 30px 0" class="profile-img">

                                </div>


                                <input value="<?php echo e($cats->title_ar); ?>" name="name_ar" placeholder="الاسم بالعربي" type="text" >

                                <input value="<?php echo e($cats->title_en); ?>" name="name_en" placeholder="الاسم بالانجليزي" type="text" >

                                <input name="time" type="time" >


				                  <div class="form-group">
				                        <b>Add Image:  </b>
				                     <input   name="cat_image" type="file" />


				                   </div>


                                <div class="add-cat-button" style="">
                                    <i class="fa fa-plus"></i>
                                    <button  type="submit">تعديل</button>
                                </div>


               </form>


                            </div>

                        </div>
                    </div>
                </div>
            </div>


        </div>


    </div>









<?php echo $__env->make('in-in-layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
