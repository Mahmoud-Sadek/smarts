<title><?php echo $__env->yieldContent('title', 'Edit Category'); ?></title>
<?php echo $__env->make('in-in-layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>






<div class="content-inner">
    <div class="container-fluid">
        <div class="row flex-row">
            <div class="col-12">
                <div class="row d-flex align-items-center mb-5">

                    <div class="col-lg-12">


         <!-- start form ************************* -->
               <form action="<?php echo e(route('category.update', $cats->id )); ?>" method="POST" enctype="multipart/form-data" class="form-group">
                        <input type="hidden" name="_method" value="PUT">
                        <?php echo e(csrf_field()); ?>


                <?php if($errors ->any() ): ?>
                       <div class="bs-example text-center">

                       <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                             <div class="alert alert-danger ">

                                  <strong>Warning! </strong> <?php echo e($error); ?>.

                             </div>

                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>


                <?php endif; ?>


                        <?php echo e(csrf_field()); ?>


                    <input name="parent_id" value="0" type="text" required hidden>

                    <input name="son_id" value="0" type="text" required hidden>

                        <label for="file-upload" class="custom-file-upload">
                            <i class="la la-lg la-cloud-upload"></i> &nbsp;
                            تحميل صورة
                        </label>
                        <input name="image" id="file-upload" type="file" />
                        <br><br>
                        <div class="mt-5 mb-5 position-relative">
                            <div class="group material-input">
                                <input value="<?php echo e($cats->title_ar); ?>" name="name_ar" type="text" required>
                                <span class="highlight"></span>
                                <span class="bar"></span>
                                <label>الاسم بالعربي</label>
                            </div>
                        </div>
                        <div class="mt-5 mb-5 position-relative">
                            <div class="group material-input">
                                <input value="<?php echo e($cats->title_en); ?>" name="name_en" type="text" required>
                                <span class="highlight"></span>
                                <span class="bar"></span>
                                <label>الاسم بالانجليزي</label>
                            </div>
                        </div>

                   <button type="submit" class="add text-center">حفظ التعديلات</button>


     </form>



                    </div>
                </div>

            </div>
        </div>
        <!-- End Row -->
    </div>
    <!-- End Container -->

    <a href="#" class="go-top"><i class="la la-arrow-up"></i></a>

</div>
</div>
<!-- End Page Content -->
</div>





<?php echo $__env->make('in-in-layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
