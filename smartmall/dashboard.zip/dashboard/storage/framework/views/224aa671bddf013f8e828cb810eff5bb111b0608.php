<?php

//Category model
use App\model\Offer;

// 
// $offer = Offer::all();
//
// echo $offer;


?>
