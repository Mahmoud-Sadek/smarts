<title><?php echo $__env->yieldContent('title', 'Add Admins'); ?></title>
<?php echo $__env->make('in-layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>






        <div class="main-panel">

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xs-offset-3 col-xs-6 col-xs-offset-3 add-admin-container">
                            <div class="add-admin-img">
                                <p>اضافة مسئول</p>
                            </div>
                            <div class="add-admin-form">


                      <form method="POST" action="<?php echo e(route('admin.store')); ?>" style="width: 50%">

                                              <?php echo e(csrf_field()); ?>


                                             <?php if($errors ->any() ): ?>
                                                    <div class="bs-example text-center">

                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                          <div class="alert alert-danger ">

                                                               <strong>Warning! </strong> <?php echo e($error); ?>.

                                                          </div>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             </div>


                                             <?php endif; ?>
                                    <input name="name" placeholder="الاسم بالعربي" type="text">
                                    <input name="admin_email" placeholder="البريد الالكتروني" type="email">
                                    <input name="password" placeholder="كلمة السر" type="password">



                                    <div class="add-admin-button" style="">
                                        <i class="fa fa-plus"></i>
                                        <button type="submit">اضافة</button>
                                    </div>
                                </form>


                            </div>

                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>










<?php echo $__env->make('in-layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
