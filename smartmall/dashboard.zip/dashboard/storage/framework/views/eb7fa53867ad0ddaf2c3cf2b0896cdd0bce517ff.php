<title><?php echo $__env->yieldContent('title', 'Admins'); ?></title>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<ul class="nav navbar-left top-nav">
    <li>
           <a  href="<?php echo e(route('admin.create')); ?>" class="btn btn-default">
               اضافه مسئول جديد
           </a>
       </li>
</ul>
</div>



   <!-- /.navbar-collapse -->
</nav>


        <div class="main-panel">

            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="card">
                            <div class="content table-responsive table-full-width">
                                <table class="table">
                                    <thead>
                                        <th>الاسم </th>
                                        <th>البريد الالكتروني</th>
                                        <th>Action</th>

                                    </thead>
                                    <tbody>
                      <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <p><?php echo e($admin->name); ?></p>
                                            </td>

                                            <td>
                                                <p>
                                                  <?php

                                                   echo $admin->admin_email ;


                                                   ?>


                                                </p>
                                            </td>

                                            <td>
                                                <div>
                                                    <!-- <button onclick="window.location.href='edit-admin.html'" class="btn btn-primary" type="button">تعديل</button> -->
                                                    <form method="post" action="<?php echo e(route('admin.destroy', $admin->id)); ?>" style="display:inline">
                                                             <?php echo e(csrf_field()); ?>

                                                             <?php echo e(method_field('DELETE')); ?>

                                                       <button   class="btn btn-danger">مسح</button>
                                                    </form>

                                                </div>
                                            </td>




                                        </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>


                    </div>
                </div>
            </div>



        </div>
    </div>










<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
