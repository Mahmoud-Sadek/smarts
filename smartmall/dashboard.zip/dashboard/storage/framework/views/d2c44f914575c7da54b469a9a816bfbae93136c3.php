<title><?php echo $__env->yieldContent('title', 'Show'); ?></title>
<?php echo $__env->make('in-layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div class="main-panel">
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="card">
                            <div class="content table-responsive table-full-width">
                                <table class="table">
                                    <thead>


                                        <th>الاسم بالعربي</th>
                                        <th>الاسم بالانجليزي</th>
                                        <th>السعر الاصلي</th>
                                        <th>السعر بعد الخصم</th>
                                        <th>الكمية</th>
                                        <th>الكمية المباعة</th>
                                        <th>صورة المنتج</th>



                                    </thead>
                                    <tbody>
                                        <tr>

                                          <td>
                                              <p><?php echo e($pro->name_ar); ?></p>
                                          </td>
                                          <td>
                                              <p><?php echo e($pro->name_en); ?></p>
                                          </td>
                                           <td>
                                              <p><?php echo e($pro->price); ?></p>
                                          </td>
                                          <td>
                                              <p><?php echo e($pro->offer_price); ?></p>
                                          </td>
                                            <td>
                                                <p><?php echo e($pro->quantity); ?></p>
                                            </td>
                                            <td>
                                                <p><?php echo e($pro->selling_quantity); ?></p>
                                            </td>
                                              <td>
                                                <img src="../../storage/app/avatar/jacket.jpg">
                                            </td>





                                        </tr>

                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>
                </div>
            </div>


        </div>
    </div>

    <?php echo $__env->make('in-layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
