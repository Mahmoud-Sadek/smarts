<title><?php echo $__env->yieldContent('title', 'product'); ?></title>
<?php echo $__env->make('layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>




            <div class="content-inner">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-xl-12">
                            <!-- Sorting -->
                            <div class="widget has-shadow">
                                <div class="widget-body">
                                    <div class="table-responsive">
                                        <button onclick="" class="add-new"><a href="<?php echo e(url('/product/create')); ?>"> اضافة منتج جديد</a></button>

                                        <table id="sorting-table" class="table mb-0">
                                            <thead>
                                                <tr>
                                                    <th>صورة المنتج</th>
                                                    <th>الاسم بالعربية</th>
                                                    <th>الاسم بالانجليزية</th>
                                                    <th>السعر الاصلي</th>
                                                    <th>نسبة الخصم</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>



<?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <td><img style="width:80px; height:80px" src="storage/app/<?php echo e($pro->image1); ?>"></td>
                                                    <td><span class="text-primary"><?php echo e($pro->name_en); ?></span></td>
                                                    <td><?php echo e($pro->name_ar); ?></td>
                                                    <td><?php echo e($pro->price); ?>$</td>
                                                    <td><?php echo e($pro->offer_price); ?>%</td>
                                                    <td class="td-actions">
                                                      <a href="<?php echo e(route('product.edit', $pro->id)); ?>"><i class="la la-edit edit"></i></a>

                                                        <form method="post" action="<?php echo e(route('product.destroy', $pro->id)); ?>" style="display:inline">
                                                                 <?php echo e(csrf_field()); ?>

                                                                 <?php echo e(method_field('DELETE')); ?>


                                                           <button type="submit"><i class="la la-close delete"></i></button>
                                                        </form>
                                                        <a href="<?php echo e(route('product.show', $pro->id)); ?>"><i class="la la-eye view"></i></a>
                                                    </td>
                                                </tr>


  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                            </div>
                            <!-- End Sorting -->
                        </div>

                    </div>
                    <!-- End Row -->
                </div>
                <!-- End Container -->

            </div>
        </div>
        <!-- End Page Content -->
    </div>



<?php echo $__env->make('layout/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
