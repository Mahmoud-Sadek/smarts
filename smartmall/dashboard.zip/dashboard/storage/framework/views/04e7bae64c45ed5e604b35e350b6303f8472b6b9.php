<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title> Add Products</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link href="../../css/bootstrap.min.css" rel="stylesheet" />
    <link href="../../css/animate.min.css" rel="stylesheet" />
    <link href="../../css/dashboard.css?v=1.4.0" rel="stylesheet" />
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>

</head>

<body>

  <?php

  use App\model\Category;
  use App\model\Brand;
  use App\model\Offer;

  $cats = Category::all();
  $brands = Brand::all();
  $offers = Offer::all();


  ?>


            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xs-12 add-product-container">
                            <div class="add-product-img">
                                <p>تعديل منتج</p>
                            </div>
                            <div class="row">
                                <div class="col-xs-6">
                                    <div class="add-product-form">


   <!-- start form ************************* -->
         <form style="width: 60%"  action="<?php echo e(route('product.update', $pro->id )); ?>" method="POST" enctype="multipart/form-data" class="form-group">
                  <input type="hidden" name="_method" value="PUT">
                  <?php echo e(csrf_field()); ?>


                           <?php if($errors ->any() ): ?>
                                  <div class="bs-example text-center">

                                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="alert alert-danger ">

                                             <strong>Warning! </strong> <?php echo e($error); ?>.

                                        </div>

                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>


                           <?php endif; ?>


 <div style="position: relative; text-align: center; margin: 30px 0" class="profile-img">
       <div class="file-upload">
           <label for="upload" class="file-upload__label"> <img class="small" src="../../../storage/app/avatar/plus2.ico"> </label>
           <input id="upload" class="file-upload__input" type="file" name="file-upload">
       </div>


   </div>

                                            <input value="<?php echo e($pro->name_ar); ?>" name="name_ar" placeholder="الاسم بالعربي" type="text">
                                            <input value="<?php echo e($pro->name_en); ?>" name="name_en" placeholder="الاسم بالانجليزي" type="text">
                                            <input value="<?php echo e($pro->price); ?>" value="<?php echo e($pro->name_ar); ?>" name="price" placeholder="السعر الاصلي" type="text">
                                            <input value="<?php echo e($pro->quantity); ?>" name="offer_price" placeholder="نسبه الخصم" type="text">
                                            <input value="<?php echo e($pro->selling_quantity); ?>" name="quantity" placeholder="الكمية" type="text">
                                            <input value="<?php echo e($pro->offer_price); ?>" name="selling_quantity" placeholder="الكمية المباعة" type="text">
                                            <input value="<?php echo e($pro->offer_price); ?>" name="time" placeholder="الكمية المباعة" type="text">

                                            <select name="cat_id">

                                                <option disabled value="0">Category</option>
                                                <option value="0">None</option>

                                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->title_en); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>

                                            <select name="brand_id">

                                              <option disabled value="0">Brands</option>

                                                <option value="0">None</option>

                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->title_en); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>


                                            <select name="offer_id">
                                                <option disabled value="0">Offers</option>
                                                <option value="0">None</option>

                                                <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option value="<?php echo e($offer->id); ?>"><?php echo e($offer->title_en); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>





                                            <label style=" float:right" for="">تفاصيل بالعربي</label>
                                            <textarea name="detail_ar" style="float:right" style="width: 60%"   rows="5" cols="60"> <?php echo e($pro->infromation_ar); ?></textarea>
                                            <div class="clearfix"></div>
                                            <label style=" float:right" for="">تفاصيل بالانجليزي</label>
                                            <textarea name="detail_en" style=" float:right"  rows="5" cols="60"><?php echo e($pro->infromation_en); ?></textarea>


                                    </div>

                                </div>
                                <div class="col-xs-6 images">
                                    <div class="form-group text-right">
                                        <label style="color: black;display: block">اضافة عدة صور</label>
                                        <input name="image1" style="display: inline-block" id="Idimage" type='file' onchange="readURL(this);" />
                                        <div class="progress">
                                            <div id="bar" data-percentage="0%" width='50%' class="progress-bar progress-bar-success" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <input name="image2" style="display: inline-block" id="Idimage" type='file' onchange="readURL(this);" />
                                        <div class="progress">
                                            <div id="bar" data-percentage="0%" width='50%' class="progress-bar progress-bar-success" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <input name="image3" style="display: inline-block" id="Idimage" type='file' onchange="readURL(this);" />
                                        <div class="progress">
                                            <div id="bar" data-percentage="0%" width='50%' class="progress-bar progress-bar-success" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <input name="image4" style="display: inline-block" id="Idimage" type='file' onchange="readURL(this);" />
                                        <div class="progress">
                                            <div id="bar" data-percentage="0%" width='50%' class="progress-bar progress-bar-success" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <input name="image5" style="display: inline-block" id="Idimage" type='file' onchange="readURL(this);" />
                                        <div class="progress">
                                            <div id="bar" data-percentage="0%" width='50%' class="progress-bar progress-bar-success" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>

                                        <label style="width: 60%; float:right" for="">معلومات بالعربي</label>
                                        <textarea name="infromation_ar" style="width: 60%; float:right" style="width: 60%"  rows="5" cols="60"><?php echo e($pro->detail_ar); ?></textarea>
                                        <div class="clearfix"></div>
                                        <label style="width: 60%; float:right" for="">معلومات بالانجليزي</label>
                                        <textarea name="infromation_en" style="width: 60%; float:right"   rows="5" cols="60"><?php echo e($pro->detail_en); ?></textarea>

                                    </div>

                                </div>
                            </div>
                            <div class="add-product-button" style="">
                                <i class="fa fa-plus"></i>
                                <button type="submit">اضافة</button>
                            </div>

                          </form>
                        </div>

                    </div>
                </div>
            </div>


        </div>






<?php echo $__env->make('in-layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
