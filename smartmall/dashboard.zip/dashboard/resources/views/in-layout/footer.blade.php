</div>
<!-- Begin Vendor Js -->
<script src="../assets/vendors/js/base/jquery.min.js"></script>
<script src="../assets/vendors/js/base/core.min.js"></script>
<!-- End Vendor Js -->
<!-- Begin Page Vendor Js -->
<script src="../assets/vendors/js/datatables/datatables.min.js"></script>
<script src="../assets/vendors/js/datatables/dataTables.buttons.min.js"></script>
<script src="../assets/vendors/js/datatables/jszip.min.js"></script>
<script src="../assets/vendors/js/datatables/buttons.html5.min.js"></script>
<script src="../assets/vendors/js/datatables/pdfmake.min.js"></script>
<script src="../assets/vendors/js/datatables/vfs_fonts.js"></script>
<script src="../assets/vendors/js/datatables/buttons.print.min.js"></script>
<script src="../assets/vendors/js/nicescroll/nicescroll.min.js"></script>
<script src="../assets/vendors/js/app/app.min.js"></script>
<!-- End Page Vendor Js -->
<!-- Begin Page Snippets -->
<script src="../assets/js/components/tables/tables.js"></script>

<!-- End Page Snippets -->

</body>

</html>
